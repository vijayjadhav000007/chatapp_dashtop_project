import java.util.Scanner;

public class main1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Shop shop = new Shop();
        boolean exit = false;

        while (!exit) {
            System.out.println("============================ *** WELCOME TO MOBILE SHOPIFY STORY *** =======================");
            System.out.println("\t =========================*** ENTER YOUR CHOICE *** ========================");
            System.out.println("1]. ADD MOBILE  \t\t\t\t      2].VIEW INVENTORY");
            System.out.println("3]. PURCHASE MOBILE \t\t\t\t     4].VIEW TOTAL EARNINGS");
            System.out.println("5]. EXIT ");
            System.out.println("=============================== *** ENTER 5 TO EXIT *** ===============================");
            System.out.print("Enter your choice: "); 
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (choice) {
                case 1:
                System.out.println("======================= *** ENTER BRAND DETAILS *** =======================");
                    System.out.print("Enter brand: ");
                    String brand = scanner.nextLine();
                    System.out.print("Enter model: ");
                    String model = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter stock: ");
                    int stock = scanner.nextInt();
                    shop.addMobile(new Mobile(brand, model, price, stock));
                    System.out.println("Mobile added to inventory!");
                    break;
               
                case 2:
                    System.out.println("=====================*** INVENTORY DETAILS *** =======================");
                    for (Mobile mobile : shop.getInventory()) {
                        System.out.println(mobile);
                    }
                    break;
                   
                case 3:
                System.out.println("======================= *** ENTER PURCHASE DETAILS *** =======================");
                    System.out.print("Enter model to purchase: ");
                    String purchaseModel = scanner.nextLine();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    shop.purchaseMobile(purchaseModel, quantity);
                    break;
                case 4:
                System.out.println("======================= *** TOTAL EAENINGS DETAILS *** =======================");
                    System.out.println("Total Earnings: INR" + shop.getTotalEarnings());
                    break;
                case 5:
                    System.out.println("Exiting... Goodbye!");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
