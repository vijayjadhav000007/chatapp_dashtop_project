import java.util.ArrayList;
import java.util.List;

public class Shop {
    private List<Mobile> inventory;
    private double totalEarnings;

    public Shop () {
        this.inventory = new ArrayList<>();
        this.totalEarnings = 0;
    }

    public void addMobile(Mobile mobile) {
        inventory.add(mobile);
    }

    public List<Mobile> getInventory() {
        return inventory;
    }

    public void purchaseMobile(String model, int quantity) {
    for (Mobile mobile : inventory) {
    if (mobile.getModel().equalsIgnoreCase(model)) {
     if (mobile.getStock() >= quantity) {
     mobile.setStock(mobile.getStock() - quantity);
    double sale = mobile.getPrice() * quantity;
     totalEarnings += sale;
     System.out.println("Purchase successful! Total: INR" + sale);
      } else {
      System.out.println("Not enough stock available!");
     }
         return;
      }
        }
        System.out.println("Mobile model not found!");
    }

    public double getTotalEarnings() {
        return totalEarnings;
        
    }
}
