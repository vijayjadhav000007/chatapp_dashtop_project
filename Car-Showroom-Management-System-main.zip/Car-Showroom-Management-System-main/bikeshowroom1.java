import java.io.*;
import java.util.Scanner;

class BikeShowroom1 {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            // मेनू दाखवणे
            System.out.println("\n--- Bike Showroom Menu ---");
            System.out.println("1. Add Bike Details");
            System.out.println("2. Add Customer Details");
            System.out.println("3. Display Bike Details");
            System.out.println("4. Display Customer Details");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addBikeDetails();
                    break;
                case 2:
                    addCustomerDetails();
                    break;
                case 3:
                    displayBikeDetails();
                    break;
                case 4:
                    displayCustomerDetails();
                    break;
                case 5:
                    System.out.println("Exiting... Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);

        sc.close();
    }

    // बाईक डिटेल्स ऍड करण्याची पद्धत
    public static void addBikeDetails() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("bikes.txt", true));
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bike Model: ");
        String model = sc.nextLine();
        System.out.print("Enter Bike Price: ");
        double price = sc.nextDouble();
        System.out.print("Enter Bike series: ");
        double se1 = sc.nextDouble();

        writer.write("Model: " + model + ", Price: " + price + "\n");
        writer.close();
        System.out.println("Bike details added successfully!");
    }

    // कस्टमर डिटेल्स ऍड करण्याची पद्धत
    public static void addCustomerDetails() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("customers.txt", true));
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Customer Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Customer Contact: ");
        String contact = sc.nextLine();

        writer.write("Name: " + name + ", Contact: " + contact + "\n");
        writer.close();
        System.out.println("Customer details added successfully!");
    }

    // बाईक डिटेल्स डिस्प्ले करणे
    public static void displayBikeDetails() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("bikes.txt"));
        String line;

        System.out.println("\n--- Bike Details ---");
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();
    }

    // कस्टमर डिटेल्स डिस्प्ले करणे
    public static void displayCustomerDetails() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("customers.txt"));
        String line;

        System.out.println("\n--- Customer Details ---");
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();}
}
